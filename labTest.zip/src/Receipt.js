import React from 'react';

function Receipt({ transactionDetails }) {
  return (
    <div>
      <h2>Transaction Details</h2>
      <p>Transaction Hash: {transactionDetails.transactionHash}</p>
      <p>Block Hash: {transactionDetails.blockHash}</p>
      <p>Block Number: {transactionDetails.blockNumber}</p>
      <p>Source: {transactionDetails.source}</p>
      <p>Destination: {transactionDetails.destination}</p>
      <p>Gas Used: {transactionDetails.gasUsed}</p>
    </div>
  );
}

export default Receipt;
