import React, { Component } from 'react';
import Receipt from './Receipt';

class Transfer extends Component {
  sourceAccount = '0x742D6eB10Fe16da89491758e77A6321fC7E17E86';
  destinationAccount = '0x742D6eB10Fe16da89491758e77A6321fC7E17E86'; 
  state = {
    amount: '',
    transactionDetails: null, 
  };

  handleAmountChange = (event) => {
    this.setState({ amount: event.target.value });
  };

  
  
        handleSubmit = (event) => {
    event.preventDefault();


 const transactionDetails = {
      transactionHash: '0x1234567890abcdef',
      blockHash: '0xabcdef1234567890',
      blockNumber: 226929,
      source: this.sourceAccount,
      destination: this.destinationAccount,
      gasUsed: 7003,
    };

    this.setState({ transactionDetails });
  };

  render() {
    return (
      <div>
        <h1>Ethereum Transaction</h1>
        <p>Source Account: {this.sourceAccount}</p>
        <p>Destination Account: {this.destinationAccount}</p>
        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            placeholder="Enter Amount"
            value={this.state.amount}
            onChange={this.handleAmountChange}
          />
          <button type="submit">Submit</button>
        </form>
        {this.state.transactionDetails && (
          <Receipt transactionDetails={this.state.transactionDetails} />
        )}
      </div>
    );
  }
}



export default Transfer;
